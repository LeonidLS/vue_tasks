
var app = new Vue({
    el: '#app', 
    data: {
        stroka: "Hello, Dolly! ... This is Louis, Dolly!",
    },

    methods: {
    },

    filters: {
        shorten: function(string, int){
            if (string.length>int) {
                return string.substr(0, int)
            }
        },

        lengthen: function(string, int){
            n=0;
            while(string.length<int){
               string+=n;
                n+=1;
           }           
           return string
        }
    }     
})
